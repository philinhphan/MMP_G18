public enum PlayerState
{
    Normal,
    FlappyBird
}